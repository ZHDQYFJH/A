// 用户角色
export type UserRole = 'user' | 'admin';

// 知识条目状态
export type KnowledgeStatus = 'enabled' | 'disabled' | 'pending' | 'rejected';

// 用户资料
export interface Profile {
  id: string;
  username: string;
  email: string | null;
  role: UserRole;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// 知识库分类
export interface KnowledgeCategory {
  id: string;
  name: string;
  description: string | null;
  parent_id: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
  children?: KnowledgeCategory[];
}

// 知识条目
export interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  keywords: string[];
  category_id: string | null;
  status: KnowledgeStatus;
  created_by: string | null;
  reviewed_by: string | null;
  review_comment: string | null;
  created_at: string;
  updated_at: string;
  category?: KnowledgeCategory;
}

// AI 引擎配置
export interface AiConfig {
  id: string;
  platform: string;
  api_key: string | null;
  api_base_url: string | null;
  model_name: string;
  system_prompt: string;
  temperature: number;
  max_tokens: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// 对话会话
export interface Conversation {
  id: string;
  user_id: string;
  title: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  profile?: Profile;
}

// 对话消息
export interface ConversationMessage {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant';
  content: string;
  knowledge_refs: string[];
  created_at: string;
}

// 聊天消息（前端用）
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isLoading?: boolean;
  created_at?: string;
}
