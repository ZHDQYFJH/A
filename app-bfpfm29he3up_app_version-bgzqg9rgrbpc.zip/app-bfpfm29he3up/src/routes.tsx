import type { ReactNode } from 'react';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ChatPage from './pages/ChatPage';
import KnowledgeManagePage from './pages/admin/KnowledgeManagePage';
import AiConfigPage from './pages/admin/AiConfigPage';
import LogsPage from './pages/admin/LogsPage';
import UsersPage from './pages/admin/UsersPage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: '登录',
    path: '/login',
    element: <LoginPage />,
    public: true,
  },
  {
    name: '注册',
    path: '/register',
    element: <RegisterPage />,
    public: true,
  },
  {
    name: '智能问答',
    path: '/chat',
    element: <ChatPage />,
  },
  {
    name: '知识库管理',
    path: '/admin/knowledge',
    element: <KnowledgeManagePage />,
  },
  {
    name: 'AI 引擎配置',
    path: '/admin/ai-config',
    element: <AiConfigPage />,
  },
  {
    name: '对话日志',
    path: '/admin/logs',
    element: <LogsPage />,
  },
  {
    name: '用户管理',
    path: '/admin/users',
    element: <UsersPage />,
  },
];
