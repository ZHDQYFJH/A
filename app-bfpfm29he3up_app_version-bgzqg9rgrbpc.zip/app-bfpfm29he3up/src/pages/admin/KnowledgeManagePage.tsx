import React, { useState, useEffect, useCallback, useRef } from 'react';
import AdminLayout from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Search, CheckCircle, XCircle, Clock, Upload, FileSpreadsheet, AlertCircle } from 'lucide-react';
import * as XLSX from 'xlsx';
import type { KnowledgeCategory, KnowledgeItem, KnowledgeStatus } from '@/types/types';

// 批量导入相关类型
interface ImportRow {
  rowIndex: number;
  title: string;
  content: string;
  keywords: string;
  category: string;
}

interface ImportResult {
  total: number;
  success: number;
  failed: number;
  errors: Array<{ row: number; title: string; reason: string }>;
}

// 列名映射（支持中英文）
const FIELD_ALIASES: Record<string, string[]> = {
  title: ['title', '标题', '名称', 'name'],
  content: ['content', '内容', '正文', 'text', 'body'],
  keywords: ['keywords', '关键词', '关键字', 'keyword', 'tags', '标签'],
  category: ['category', '分类', '类别', '类型', 'type', 'class'],
};

const statusConfig: Record<KnowledgeStatus, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  enabled: { label: '已启用', variant: 'default' },
  disabled: { label: '已禁用', variant: 'secondary' },
  pending: { label: '待审核', variant: 'outline' },
  rejected: { label: '已驳回', variant: 'destructive' },
};

const KnowledgeManagePage: React.FC = () => {
  const [categories, setCategories] = useState<KnowledgeCategory[]>([]);
  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [pendingItems, setPendingItems] = useState<KnowledgeItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // 分类表单
  const [catDialogOpen, setCatDialogOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<KnowledgeCategory | null>(null);
  const [catForm, setCatForm] = useState({ name: '', description: '', sort_order: '0' });

  // 知识条目表单
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<KnowledgeItem | null>(null);
  const [itemForm, setItemForm] = useState({
    title: '',
    content: '',
    keywords: '',
    category_id: 'none',
    status: 'pending' as KnowledgeStatus,
  });

  // 审核对话框
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [reviewingItem, setReviewingItem] = useState<KnowledgeItem | null>(null);
  const [reviewComment, setReviewComment] = useState('');

  // 批量导入状态
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importStage, setImportStage] = useState<'upload' | 'preview' | 'result'>('upload');
  const [isDragging, setIsDragging] = useState(false);
  const [importRows, setImportRows] = useState<ImportRow[]>([]);
  const [importFileName, setImportFileName] = useState('');
  const [importProgress, setImportProgress] = useState(0);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ======= 批量导入逻辑 =======

  /** 将工作表行数据映射到标准字段 */
  const mapRowToFields = (row: Record<string, unknown>): ImportRow | null => {
    const lowerKeys = Object.keys(row).reduce<Record<string, unknown>>((acc, k) => {
      acc[k.toLowerCase().trim()] = row[k];
      return acc;
    }, {});

    const findField = (fieldKey: string): string => {
      for (const alias of FIELD_ALIASES[fieldKey]) {
        if (lowerKeys[alias] !== undefined && lowerKeys[alias] !== null) {
          return String(lowerKeys[alias]).trim();
        }
      }
      return '';
    };

    return {
      rowIndex: 0,
      title: findField('title'),
      content: findField('content'),
      keywords: findField('keywords'),
      category: findField('category'),
    };
  };

  /** 解析文件为行数组 */
  const parseFile = (file: File): Promise<ImportRow[]> => {
    return new Promise((resolve, reject) => {
      const ext = file.name.split('.').pop()?.toLowerCase();
      if (!['xlsx', 'xls', 'csv'].includes(ext || '')) {
        reject(new Error('不支持的文件格式，请上传 .xlsx / .xls / .csv 文件'));
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const wb = XLSX.read(data, { type: 'array' });
          const ws = wb.Sheets[wb.SheetNames[0]];
          const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, {
            defval: '',
            raw: false,
          });

          if (rawRows.length === 0) {
            reject(new Error('文件内容为空，请检查文件'));
            return;
          }

          const rows: ImportRow[] = rawRows.map((r, i) => {
            const mapped = mapRowToFields(r);
            return { ...(mapped ?? { title: '', content: '', keywords: '', category: '' }), rowIndex: i + 2 };
          });
          resolve(rows);
        } catch {
          reject(new Error('文件解析失败，请确认文件格式正确'));
        }
      };
      reader.onerror = () => reject(new Error('文件读取失败'));
      reader.readAsArrayBuffer(file);
    });
  };

  const handleFileSelect = async (file: File) => {
    try {
      const rows = await parseFile(file);
      setImportFileName(file.name);
      setImportRows(rows);
      setImportStage('preview');
    } catch (err: unknown) {
      toast.error((err as Error).message);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
    e.target.value = '';
  };

  /** 执行批量导入 */
  const executeImport = async () => {
    if (importRows.length === 0) return;
    setImporting(true);
    setImportProgress(0);

    const result: ImportResult = { total: importRows.length, success: 0, failed: 0, errors: [] };

    // 构建分类名称→ID映射（忽略大小写）
    const catMap = new Map<string, string>();
    categories.forEach((c) => catMap.set(c.name.toLowerCase().trim(), c.id));

    const BATCH = 10;
    for (let i = 0; i < importRows.length; i += BATCH) {
      const batch = importRows.slice(i, i + BATCH);
      const insertPayload: Array<{
        title: string;
        content: string;
        keywords: string[];
        category_id: string | null;
        status: string;
      }> = [];
      const batchErrors: ImportResult['errors'] = [];

      for (const row of batch) {
        // 必填校验
        if (!row.title) {
          batchErrors.push({ row: row.rowIndex, title: row.title || '(空)', reason: '标题不能为空' });
          continue;
        }
        if (!row.content) {
          batchErrors.push({ row: row.rowIndex, title: row.title, reason: '内容不能为空' });
          continue;
        }

        // 分类匹配
        let categoryId: string | null = null;
        if (row.category.trim()) {
          const matched = catMap.get(row.category.trim().toLowerCase());
          if (!matched) {
            batchErrors.push({ row: row.rowIndex, title: row.title, reason: `分类"${row.category}"不存在，请先在系统中创建该分类` });
            continue;
          }
          categoryId = matched;
        }

        const keywords = row.keywords
          ? row.keywords.split(/[,，\s]+/).map((k) => k.trim()).filter(Boolean)
          : [];

        insertPayload.push({
          title: row.title,
          content: row.content,
          keywords,
          category_id: categoryId,
          status: 'enabled',
        });
      }

      if (insertPayload.length > 0) {
        const { error } = await supabase.from('knowledge_items').insert(insertPayload);
        if (error) {
          insertPayload.forEach((p) =>
            batchErrors.push({ row: 0, title: p.title, reason: '数据库写入失败：' + error.message })
          );
        } else {
          result.success += insertPayload.length;
        }
      }

      result.errors.push(...batchErrors);
      result.failed += batchErrors.length;

      setImportProgress(Math.round(((i + BATCH) / importRows.length) * 100));
    }

    result.failed = result.total - result.success;
    setImportResult(result);
    setImportStage('result');
    setImporting(false);

    if (result.success > 0) {
      loadItems();
      toast.success(`成功导入 ${result.success} 条知识条目`);
    }
  };

  const resetImportDialog = () => {
    setImportStage('upload');
    setImportRows([]);
    setImportFileName('');
    setImportProgress(0);
    setImporting(false);
    setImportResult(null);
  };

  const downloadTemplate = () => {
    const ws = XLSX.utils.aoa_to_sheet([
      ['标题', '内容', '关键词', '分类'],
      ['图书馆借阅规定', '本校图书馆每位学生可借阅5本图书...', '图书馆,借阅,规定', '校园服务'],
      ['请假办理流程', '学生请假需填写请假申请表...', '请假,流程,办理', '办事流程'],
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '知识条目模板');
    XLSX.writeFile(wb, '知识条目导入模板.xlsx');
  };

  // ======= 批量导入逻辑 END =======

  const loadCategories = useCallback(async () => {    const { data, error } = await supabase
      .from('knowledge_categories')
      .select('*')
      .order('sort_order', { ascending: true });
    if (!error) setCategories(Array.isArray(data) ? data : []);
  }, []);

  const loadItems = useCallback(async () => {
    setLoading(true);
    const query = supabase
      .from('knowledge_items')
      .select('*, category:knowledge_categories(id, name)')
      .order('created_at', { ascending: false });

    const { data, error } = await query;
    setLoading(false);

    if (!error && data) {
      const all = Array.isArray(data) ? data : [];
      setItems(all.filter((i) => i.status !== 'pending'));
      setPendingItems(all.filter((i) => i.status === 'pending'));
    }
  }, []);

  useEffect(() => {
    loadCategories();
    loadItems();
  }, [loadCategories, loadItems]);

  // 分类操作
  const openCatDialog = (cat?: KnowledgeCategory) => {
    if (cat) {
      setEditingCat(cat);
      setCatForm({ name: cat.name, description: cat.description || '', sort_order: String(cat.sort_order) });
    } else {
      setEditingCat(null);
      setCatForm({ name: '', description: '', sort_order: '0' });
    }
    setCatDialogOpen(true);
  };

  const saveCat = async () => {
    if (!catForm.name.trim()) { toast.error('分类名称不能为空'); return; }
    const payload = {
      name: catForm.name.trim(),
      description: catForm.description.trim() || null,
      sort_order: parseInt(catForm.sort_order) || 0,
    };
    if (editingCat) {
      const { error } = await supabase.from('knowledge_categories').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editingCat.id);
      if (error) { toast.error('更新失败'); return; }
      toast.success('分类已更新');
    } else {
      const { error } = await supabase.from('knowledge_categories').insert(payload);
      if (error) { toast.error('创建失败'); return; }
      toast.success('分类已创建');
    }
    setCatDialogOpen(false);
    loadCategories();
  };

  const deleteCat = async (id: string) => {
    const hasItems = items.some((i) => i.category_id === id);
    if (hasItems) { toast.error('该分类下存在知识条目，请先移除或删除相关条目'); return; }
    const { error } = await supabase.from('knowledge_categories').delete().eq('id', id);
    if (error) { toast.error('删除失败'); return; }
    toast.success('分类已删除');
    loadCategories();
  };

  // 知识条目操作
  const openItemDialog = (item?: KnowledgeItem) => {
    if (item) {
      setEditingItem(item);
      setItemForm({
        title: item.title,
        content: item.content,
        keywords: item.keywords.join(', '),
        category_id: item.category_id || 'none',
        status: item.status,
      });
    } else {
      setEditingItem(null);
      setItemForm({ title: '', content: '', keywords: '', category_id: 'none', status: 'pending' });
    }
    setItemDialogOpen(true);
  };

  const saveItem = async () => {
    if (!itemForm.title.trim() || !itemForm.content.trim()) {
      toast.error('标题和内容不能为空');
      return;
    }
    const keywordsArr = itemForm.keywords.split(/[,，]+/).map((k) => k.trim()).filter(Boolean);
    const payload = {
      title: itemForm.title.trim(),
      content: itemForm.content.trim(),
      keywords: keywordsArr,
      category_id: itemForm.category_id === 'none' ? null : itemForm.category_id,
      status: itemForm.status,
      updated_at: new Date().toISOString(),
    };

    if (editingItem) {
      const { error } = await supabase.from('knowledge_items').update(payload).eq('id', editingItem.id);
      if (error) { toast.error('更新失败'); return; }
      toast.success('知识条目已更新');
    } else {
      const { error } = await supabase.from('knowledge_items').insert(payload);
      if (error) { toast.error('创建失败'); return; }
      toast.success('知识条目已创建');
    }
    setItemDialogOpen(false);
    loadItems();
  };

  const deleteItem = async (id: string) => {
    const { error } = await supabase.from('knowledge_items').delete().eq('id', id);
    if (error) { toast.error('删除失败'); return; }
    toast.success('已删除');
    loadItems();
  };

  const toggleItemStatus = async (item: KnowledgeItem) => {
    const newStatus = item.status === 'enabled' ? 'disabled' : 'enabled';
    const { error } = await supabase.from('knowledge_items').update({ status: newStatus, updated_at: new Date().toISOString() }).eq('id', item.id);
    if (error) { toast.error('操作失败'); return; }
    toast.success(newStatus === 'enabled' ? '已启用' : '已禁用');
    loadItems();
  };

  // 审核操作
  const openReview = (item: KnowledgeItem) => {
    setReviewingItem(item);
    setReviewComment('');
    setReviewDialogOpen(true);
  };

  const handleReview = async (approve: boolean) => {
    if (!reviewingItem) return;
    const { error } = await supabase
      .from('knowledge_items')
      .update({
        status: approve ? 'enabled' : 'rejected',
        review_comment: reviewComment.trim() || null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', reviewingItem.id);
    if (error) { toast.error('审核失败'); return; }
    toast.success(approve ? '已通过审核并启用' : '已驳回');
    setReviewDialogOpen(false);
    loadItems();
  };

  // 过滤知识条目
  const filteredItems = items.filter((item) => {
    const matchSearch = !searchQuery || item.title.includes(searchQuery) || item.content.includes(searchQuery);
    const matchCat = filterCategory === 'all' || item.category_id === filterCategory;
    const matchStatus = filterStatus === 'all' || item.status === filterStatus;
    return matchSearch && matchCat && matchStatus;
  });

  return (
    <AdminLayout>
      <Tabs defaultValue="items">
        <div className="flex items-center justify-between mb-4 gap-4 flex-wrap">
          <TabsList>
            <TabsTrigger value="items">知识条目</TabsTrigger>
            <TabsTrigger value="categories">知识分类</TabsTrigger>
            <TabsTrigger value="review">
              待审核
              {pendingItems.length > 0 && (
                <Badge variant="destructive" className="ml-1.5 h-4 px-1 text-xs">{pendingItems.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>
        </div>

        {/* 知识条目 Tab */}
        <TabsContent value="items" className="mt-0 space-y-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-40">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="搜索标题或内容..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="所有分类" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">所有分类</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="所有状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">所有状态</SelectItem>
                <SelectItem value="enabled">已启用</SelectItem>
                <SelectItem value="disabled">已禁用</SelectItem>
                <SelectItem value="rejected">已驳回</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => openItemDialog()} className="h-9 shrink-0">
              <Plus className="w-4 h-4 mr-1.5" />
              新增条目
            </Button>
            <Button
              variant="outline"
              onClick={() => { resetImportDialog(); setImportDialogOpen(true); }}
              className="h-9 shrink-0"
            >
              <Upload className="w-4 h-4 mr-1.5" />
              批量导入
            </Button>
          </div>

          <Card>
            <div className="w-full max-w-full overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap min-w-40">标题</TableHead>
                    <TableHead className="whitespace-nowrap">分类</TableHead>
                    <TableHead className="whitespace-nowrap">关键词</TableHead>
                    <TableHead className="whitespace-nowrap">状态</TableHead>
                    <TableHead className="whitespace-nowrap">创建时间</TableHead>
                    <TableHead className="whitespace-nowrap text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground py-8">加载中...</TableCell>
                    </TableRow>
                  ) : filteredItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground py-8">暂无数据</TableCell>
                    </TableRow>
                  ) : (
                    filteredItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="whitespace-nowrap font-medium max-w-52">
                          <span className="truncate block">{item.title}</span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-muted-foreground text-sm">
                          {(item.category as KnowledgeCategory | undefined)?.name || '未分类'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1 flex-wrap max-w-40">
                            {item.keywords.slice(0, 3).map((kw) => (
                              <Badge key={kw} variant="secondary" className="text-xs">{kw}</Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant={statusConfig[item.status].variant}>{statusConfig[item.status].label}</Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-muted-foreground text-sm">
                          {new Date(item.created_at).toLocaleDateString('zh-CN')}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openItemDialog(item)}>
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-muted-foreground hover:text-foreground"
                              onClick={() => toggleItemStatus(item)}
                              title={item.status === 'enabled' ? '禁用' : '启用'}
                            >
                              {item.status === 'enabled'
                                ? <XCircle className="w-3.5 h-3.5" />
                                : <CheckCircle className="w-3.5 h-3.5" />}
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive">
                                  <Trash2 className="w-3.5 h-3.5" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                                <AlertDialogHeader>
                                  <AlertDialogTitle>确认删除</AlertDialogTitle>
                                  <AlertDialogDescription>删除后无法恢复，是否确认删除"{item.title}"？</AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>取消</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => deleteItem(item.id)}>删除</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* 知识分类 Tab */}
        <TabsContent value="categories" className="mt-0 space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => openCatDialog()} className="h-9">
              <Plus className="w-4 h-4 mr-1.5" />
              新增分类
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((cat) => (
              <Card key={cat.id} className="h-full">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-base text-balance">{cat.name}</CardTitle>
                    <div className="flex gap-1 shrink-0">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openCatDialog(cat)}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                          <AlertDialogHeader>
                            <AlertDialogTitle>确认删除分类</AlertDialogTitle>
                            <AlertDialogDescription>
                              删除分类"{cat.name}"后，该分类下的知识条目将变为未分类。
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction onClick={() => deleteCat(cat.id)}>删除</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-pretty">{cat.description || '暂无描述'}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    排序：{cat.sort_order} · {items.filter((i) => i.category_id === cat.id).length} 个条目
                  </p>
                </CardContent>
              </Card>
            ))}
            {categories.length === 0 && (
              <div className="col-span-full text-center py-12 text-muted-foreground">
                暂无分类，请先添加知识分类
              </div>
            )}
          </div>
        </TabsContent>

        {/* 待审核 Tab */}
        <TabsContent value="review" className="mt-0 space-y-4">
          <Card>
            <div className="w-full max-w-full overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap min-w-40">标题</TableHead>
                    <TableHead className="whitespace-nowrap">分类</TableHead>
                    <TableHead className="whitespace-nowrap">提交时间</TableHead>
                    <TableHead className="whitespace-nowrap text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        <Clock className="w-8 h-8 mx-auto mb-2 opacity-40" />
                        暂无待审核条目
                      </TableCell>
                    </TableRow>
                  ) : (
                    pendingItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="whitespace-nowrap font-medium">{item.title}</TableCell>
                        <TableCell className="whitespace-nowrap text-muted-foreground text-sm">
                          {(item.category as KnowledgeCategory | undefined)?.name || '未分类'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-muted-foreground text-sm">
                          {new Date(item.created_at).toLocaleString('zh-CN')}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-right">
                          <Button size="sm" variant="outline" className="h-7" onClick={() => openReview(item)}>
                            审核
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 分类编辑对话框 */}
      <Dialog open={catDialogOpen} onOpenChange={setCatDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingCat ? '编辑分类' : '新增分类'}</DialogTitle>
            <DialogDescription>管理知识库的分类结构</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">分类名称 *</Label>
              <Input value={catForm.name} onChange={(e) => setCatForm((p) => ({ ...p, name: e.target.value }))} placeholder="如：办事流程" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">描述</Label>
              <Textarea value={catForm.description} onChange={(e) => setCatForm((p) => ({ ...p, description: e.target.value }))} placeholder="分类描述（选填）" rows={2} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">排序权重</Label>
              <Input type="number" value={catForm.sort_order} onChange={(e) => setCatForm((p) => ({ ...p, sort_order: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCatDialogOpen(false)}>取消</Button>
            <Button onClick={saveCat}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 知识条目编辑对话框 */}
      <Dialog open={itemDialogOpen} onOpenChange={setItemDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? '编辑知识条目' : '新增知识条目'}</DialogTitle>
            <DialogDescription>完善知识条目信息，帮助 AI 更准确地回答校园问题</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">标题 *</Label>
              <Input value={itemForm.title} onChange={(e) => setItemForm((p) => ({ ...p, title: e.target.value }))} placeholder="知识条目标题" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">内容 *</Label>
              <Textarea value={itemForm.content} onChange={(e) => setItemForm((p) => ({ ...p, content: e.target.value }))} placeholder="详细内容..." rows={6} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">关键词（逗号分隔）</Label>
                <Input value={itemForm.keywords} onChange={(e) => setItemForm((p) => ({ ...p, keywords: e.target.value }))} placeholder="关键词1, 关键词2" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">所属分类</Label>
                <Select value={itemForm.category_id} onValueChange={(v) => setItemForm((p) => ({ ...p, category_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="选择分类" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">未分类</SelectItem>
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">状态</Label>
              <Select value={itemForm.status} onValueChange={(v) => setItemForm((p) => ({ ...p, status: v as KnowledgeStatus }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="enabled">启用</SelectItem>
                  <SelectItem value="disabled">禁用</SelectItem>
                  <SelectItem value="pending">待审核</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setItemDialogOpen(false)}>取消</Button>
            <Button onClick={saveItem}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 审核对话框 */}
      <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>审核知识条目</DialogTitle>
            <DialogDescription>{reviewingItem?.title}</DialogDescription>
          </DialogHeader>
          {reviewingItem && (
            <div className="space-y-4 py-2">
              <div className="bg-muted rounded p-3 text-sm max-h-48 overflow-y-auto">
                <pre className="whitespace-pre-wrap font-sans text-muted-foreground">{reviewingItem.content}</pre>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">审核意见（选填）</Label>
                <Textarea value={reviewComment} onChange={(e) => setReviewComment(e.target.value)} placeholder="输入审核意见..." rows={2} />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setReviewDialogOpen(false)}>取消</Button>
            <Button variant="destructive" onClick={() => handleReview(false)}>
              <XCircle className="w-4 h-4 mr-1.5" />驳回
            </Button>
            <Button onClick={() => handleReview(true)}>
              <CheckCircle className="w-4 h-4 mr-1.5" />通过并启用
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 批量导入对话框 */}
      <Dialog
        open={importDialogOpen}
        onOpenChange={(open) => {
          if (!importing) { setImportDialogOpen(open); if (!open) resetImportDialog(); }
        }}
      >
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-balance">
              <FileSpreadsheet className="w-5 h-5 text-primary" />
              批量导入知识条目
            </DialogTitle>
            <DialogDescription>
              支持 Excel（.xlsx / .xls）和 CSV（.csv）文件，自动解析标题、内容、关键词、分类字段
            </DialogDescription>
          </DialogHeader>

          {/* 阶段：上传 */}
          {importStage === 'upload' && (
            <div className="space-y-4 py-2">
              {/* 拖拽上传区域 */}
              <div
                className={`border-2 border-dashed rounded-lg p-10 text-center cursor-pointer transition-colors ${
                  isDragging ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50 hover:bg-muted/30'
                }`}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm font-medium text-foreground">点击或拖拽文件到此处</p>
                <p className="text-xs text-muted-foreground mt-1">支持 .xlsx / .xls / .csv 格式</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                  onChange={handleFileInputChange}
                />
              </div>

              {/* 字段说明 */}
              <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                <p className="text-sm font-medium text-foreground">文件格式要求</p>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 text-xs text-muted-foreground">
                  <div className="flex gap-1.5"><span className="text-foreground font-medium">标题</span>（必填）知识条目的标题</div>
                  <div className="flex gap-1.5"><span className="text-foreground font-medium">内容</span>（必填）知识条目的详细内容</div>
                  <div className="flex gap-1.5"><span className="text-foreground font-medium">关键词</span>（选填）多个关键词用逗号分隔</div>
                  <div className="flex gap-1.5"><span className="text-foreground font-medium">分类</span>（选填）需与系统分类名称一致</div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <p className="text-xs text-muted-foreground">
                  当前系统共有 {categories.length} 个分类：
                  {categories.slice(0, 4).map(c => c.name).join('、')}
                  {categories.length > 4 ? '...' : ''}
                </p>
                <Button variant="outline" size="sm" className="h-7 text-xs shrink-0" onClick={downloadTemplate}>
                  下载模板
                </Button>
              </div>
            </div>
          )}

          {/* 阶段：预览 */}
          {importStage === 'preview' && (
            <div className="space-y-4 py-2">
              <div className="flex items-center gap-2 text-sm">
                <FileSpreadsheet className="w-4 h-4 text-primary shrink-0" />
                <span className="font-medium truncate">{importFileName}</span>
                <Badge variant="secondary" className="shrink-0">{importRows.length} 行</Badge>
              </div>

              {/* 预览表格（前10行） */}
              <div>
                <p className="text-xs text-muted-foreground mb-2">预览（前10行）</p>
                <div className="border rounded overflow-hidden">
                  <div className="w-full overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead className="bg-muted">
                        <tr>
                          <th className="px-2 py-2 text-left font-medium whitespace-nowrap">行号</th>
                          <th className="px-2 py-2 text-left font-medium whitespace-nowrap">标题</th>
                          <th className="px-2 py-2 text-left font-medium whitespace-nowrap min-w-40">内容（前50字）</th>
                          <th className="px-2 py-2 text-left font-medium whitespace-nowrap">关键词</th>
                          <th className="px-2 py-2 text-left font-medium whitespace-nowrap">分类</th>
                        </tr>
                      </thead>
                      <tbody>
                        {importRows.slice(0, 10).map((row) => (
                          <tr key={row.rowIndex} className="border-t border-border">
                            <td className="px-2 py-1.5 text-muted-foreground whitespace-nowrap">{row.rowIndex}</td>
                            <td className="px-2 py-1.5 whitespace-nowrap max-w-32">
                              {row.title ? (
                                <span className="block truncate">{row.title}</span>
                              ) : (
                                <span className="text-destructive flex items-center gap-1"><AlertCircle className="w-3 h-3" />缺失</span>
                              )}
                            </td>
                            <td className="px-2 py-1.5 text-muted-foreground">
                              {row.content ? (
                                <span className="block truncate max-w-48">{row.content.slice(0, 50)}{row.content.length > 50 ? '...' : ''}</span>
                              ) : (
                                <span className="text-destructive flex items-center gap-1"><AlertCircle className="w-3 h-3" />缺失</span>
                              )}
                            </td>
                            <td className="px-2 py-1.5 text-muted-foreground whitespace-nowrap">
                              <span className="block truncate max-w-28">{row.keywords || '—'}</span>
                            </td>
                            <td className="px-2 py-1.5 whitespace-nowrap">
                              {row.category ? (
                                <span className={categories.some(c => c.name.toLowerCase() === row.category.toLowerCase()) ? 'text-foreground' : 'text-amber-600'}>
                                  {row.category}
                                </span>
                              ) : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                {importRows.length > 10 && (
                  <p className="text-xs text-muted-foreground mt-1">还有 {importRows.length - 10} 行未显示</p>
                )}
              </div>

              {importing && (
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>正在导入...</span>
                    <span>{importProgress}%</span>
                  </div>
                  <Progress value={importProgress} className="h-2" />
                </div>
              )}
            </div>
          )}

          {/* 阶段：结果 */}
          {importStage === 'result' && importResult && (
            <div className="space-y-4 py-2">
              {/* 统计卡片 */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-muted/50 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-foreground">{importResult.total}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">总计</p>
                </div>
                <div className={`rounded-lg p-3 text-center ${importResult.success > 0 ? 'bg-green-50' : 'bg-muted/50'}`}>
                  <p className={`text-2xl font-bold ${importResult.success > 0 ? 'text-green-600' : 'text-muted-foreground'}`}>
                    {importResult.success}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">导入成功</p>
                </div>
                <div className={`rounded-lg p-3 text-center ${importResult.failed > 0 ? 'bg-red-50' : 'bg-muted/50'}`}>
                  <p className={`text-2xl font-bold ${importResult.failed > 0 ? 'text-destructive' : 'text-muted-foreground'}`}>
                    {importResult.failed}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">导入失败</p>
                </div>
              </div>

              {/* 失败详情 */}
              {importResult.errors.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-foreground mb-2">失败详情</p>
                  <ScrollArea className="h-44 border rounded">
                    <div className="p-2 space-y-1.5">
                      {importResult.errors.map((err, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs bg-red-50 px-3 py-2 rounded">
                          <AlertCircle className="w-3.5 h-3.5 text-destructive mt-0.5 shrink-0" />
                          <div className="min-w-0">
                            <span className="text-muted-foreground">第 {err.row} 行</span>
                            {err.title && <span className="text-foreground font-medium mx-1">"{err.title}"</span>}
                            <span className="text-destructive">：{err.reason}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}

              {importResult.success === importResult.total && (
                <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 px-3 py-2 rounded">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  全部导入成功！
                </div>
              )}
            </div>
          )}

          <DialogFooter className="gap-2">
            {importStage === 'upload' && (
              <Button variant="outline" onClick={() => setImportDialogOpen(false)}>取消</Button>
            )}
            {importStage === 'preview' && (
              <>
                <Button variant="outline" onClick={resetImportDialog} disabled={importing}>重新选择</Button>
                <Button onClick={executeImport} disabled={importing}>
                  {importing ? '导入中...' : `确认导入 ${importRows.length} 条`}
                </Button>
              </>
            )}
            {importStage === 'result' && (
              <>
                {importResult && importResult.failed > 0 && (
                  <Button variant="outline" onClick={resetImportDialog}>重新导入</Button>
                )}
                <Button onClick={() => { setImportDialogOpen(false); resetImportDialog(); }}>完成</Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default KnowledgeManagePage;
