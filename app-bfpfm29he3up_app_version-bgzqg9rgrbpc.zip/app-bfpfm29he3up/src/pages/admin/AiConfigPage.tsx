import React, { useState, useEffect, useCallback } from 'react';
import AdminLayout from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Save, TestTube, Bot, CheckCircle, XCircle } from 'lucide-react';
import type { AiConfig } from '@/types/types';

const AI_PLATFORMS = [
  { value: 'deepseek', label: 'DeepSeek', models: ['deepseek-chat', 'deepseek-coder'], baseUrl: 'https://api.deepseek.com' },
  { value: 'qianfan', label: '百度千帆', models: ['ERNIE-Bot', 'ERNIE-Bot-turbo', 'ERNIE-3.5-8K'], baseUrl: 'https://aip.baidubce.com' },
  { value: 'spark', label: '讯飞星火', models: ['spark-lite', 'spark-pro', 'spark-max'], baseUrl: 'https://spark-api-open.xf-yun.com' },
];

const AiConfigPage: React.FC = () => {
  const [config, setConfig] = useState<AiConfig | null>(null);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [testMessage, setTestMessage] = useState('');

  const [form, setForm] = useState({
    platform: 'deepseek',
    api_key: '',
    api_base_url: 'https://api.deepseek.com',
    model_name: 'deepseek-chat',
    system_prompt: '',
    temperature: 0.7,
    max_tokens: 2048,
  });

  const loadConfig = useCallback(async () => {
    const { data } = await supabase
      .from('ai_config')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data) {
      setConfig(data);
      setForm({
        platform: data.platform,
        api_key: data.api_key || '',
        api_base_url: data.api_base_url || '',
        model_name: data.model_name,
        system_prompt: data.system_prompt,
        temperature: parseFloat(String(data.temperature)),
        max_tokens: data.max_tokens,
      });
    }
  }, []);

  useEffect(() => {
    loadConfig();
  }, [loadConfig]);

  const handlePlatformChange = (platform: string) => {
    const found = AI_PLATFORMS.find((p) => p.value === platform);
    setForm((prev) => ({
      ...prev,
      platform,
      api_base_url: found?.baseUrl || '',
      model_name: found?.models[0] || '',
    }));
    setTestStatus('idle');
  };

  const saveConfig = async () => {
    if (!form.system_prompt.trim()) {
      toast.error('系统提示词不能为空');
      return;
    }
    setSaving(true);

    const payload = {
      platform: form.platform,
      api_key: form.api_key.trim() || null,
      api_base_url: form.api_base_url.trim(),
      model_name: form.model_name,
      system_prompt: form.system_prompt.trim(),
      temperature: form.temperature,
      max_tokens: form.max_tokens,
      is_active: true,
      updated_at: new Date().toISOString(),
    };

    if (config) {
      const { error } = await supabase.from('ai_config').update(payload).eq('id', config.id);
      if (error) { toast.error('保存失败'); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('ai_config').insert(payload);
      if (error) { toast.error('保存失败'); setSaving(false); return; }
    }

    toast.success('AI 引擎配置已保存');
    setSaving(false);
    loadConfig();
  };

  const testConnection = async () => {
    if (!form.api_key.trim()) {
      toast.error('请先填写 API 密钥');
      return;
    }
    setTesting(true);
    setTestStatus('idle');
    setTestMessage('');

    try {
      const { data, error } = await supabase.functions.invoke('campus-chat', {
        body: {
          question: '你好，请简单介绍一下自己。',
          conversationId: null,
          messages: [],
        },
      });

      if (error) {
        const errMsg = await error?.context?.text?.();
        throw new Error(errMsg || error.message);
      }

      if (data?.answer) {
        setTestStatus('success');
        setTestMessage('连接成功：' + data.answer.slice(0, 50) + '...');
      } else {
        throw new Error('未收到有效回复');
      }
    } catch (err: unknown) {
      const error = err as Error;
      setTestStatus('error');
      setTestMessage(error.message || '连接失败');
    } finally {
      setTesting(false);
    }
  };

  const currentPlatform = AI_PLATFORMS.find((p) => p.value === form.platform);

  return (
    <AdminLayout>
      <div className="max-w-3xl space-y-6">
        {/* AI 平台选择 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-balance">
              <Bot className="w-5 h-5 text-primary" />
              AI 引擎配置
            </CardTitle>
            <CardDescription className="text-pretty">
              选择并配置用于智能问答的 AI 平台，系统将使用此配置处理用户的所有问题
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* 平台选择 */}
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">AI 平台</Label>
              <div className="grid grid-cols-3 gap-3">
                {AI_PLATFORMS.map((platform) => (
                  <button
                    key={platform.value}
                    type="button"
                    onClick={() => handlePlatformChange(platform.value)}
                    className={`p-3 rounded border text-sm font-medium transition-colors ${
                      form.platform === platform.value
                        ? 'border-primary bg-primary/5 text-primary'
                        : 'border-border hover:border-primary/50 text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {platform.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 模型选择 */}
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">模型</Label>
              <Select value={form.model_name} onValueChange={(v) => setForm((p) => ({ ...p, model_name: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(currentPlatform?.models || []).map((model) => (
                    <SelectItem key={model} value={model}>{model}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* API 基础 URL */}
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">API 基础地址</Label>
              <Input
                value={form.api_base_url}
                onChange={(e) => setForm((p) => ({ ...p, api_base_url: e.target.value }))}
                placeholder="https://api.deepseek.com"
              />
            </div>

            {/* API Key */}
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">API 密钥</Label>
              <Input
                type="password"
                value={form.api_key}
                onChange={(e) => setForm((p) => ({ ...p, api_key: e.target.value }))}
                placeholder="输入 API 密钥（留空将使用系统环境变量配置）"
              />
              <p className="text-xs text-muted-foreground">
                密钥将加密存储，也可在系统环境变量中配置 DEEPSEEK_API_KEY
              </p>
            </div>

            {/* 测试连接 */}
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                onClick={testConnection}
                disabled={testing}
                className="h-9"
              >
                <TestTube className="w-4 h-4 mr-1.5" />
                {testing ? '测试中...' : '测试连接'}
              </Button>
              {testStatus === 'success' && (
                <div className="flex items-center gap-1.5 text-sm text-green-600">
                  <CheckCircle className="w-4 h-4" />
                  <span className="max-w-60 truncate">{testMessage}</span>
                </div>
              )}
              {testStatus === 'error' && (
                <div className="flex items-center gap-1.5 text-sm text-destructive">
                  <XCircle className="w-4 h-4" />
                  <span className="max-w-60 truncate">{testMessage}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* 系统提示词 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-balance">系统提示词</CardTitle>
            <CardDescription className="text-pretty">
              系统提示词定义了 AI 助手的角色、行为准则和校园场景适配规则
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={form.system_prompt}
              onChange={(e) => setForm((p) => ({ ...p, system_prompt: e.target.value }))}
              placeholder="输入系统提示词..."
              rows={8}
              className="font-mono text-sm"
            />
          </CardContent>
        </Card>

        {/* 模型参数 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-balance">模型参数</CardTitle>
            <CardDescription>调整模型的生成行为参数</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* 温度 */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-normal">温度（Temperature）</Label>
                <Badge variant="secondary">{form.temperature.toFixed(1)}</Badge>
              </div>
              <Slider
                value={[form.temperature]}
                onValueChange={([v]) => setForm((p) => ({ ...p, temperature: v }))}
                min={0}
                max={1}
                step={0.1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>保守精准（0.0）</span>
                <span>富有创意（1.0）</span>
              </div>
            </div>

            {/* 最大 Token */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-normal">最大输出 Token</Label>
                <Badge variant="secondary">{form.max_tokens}</Badge>
              </div>
              <Slider
                value={[form.max_tokens]}
                onValueChange={([v]) => setForm((p) => ({ ...p, max_tokens: v }))}
                min={256}
                max={4096}
                step={256}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>256 Token</span>
                <span>4096 Token</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 保存按钮 */}
        <div className="flex justify-end">
          <Button onClick={saveConfig} disabled={saving} className="h-10 px-6">
            <Save className="w-4 h-4 mr-1.5" />
            {saving ? '保存中...' : '保存配置'}
          </Button>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AiConfigPage;
