import React, { useState, useEffect, useCallback } from 'react';
import AdminLayout from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Search, Download, MessageSquare, Eye, Bot, User } from 'lucide-react';
import type { Conversation, ConversationMessage } from '@/types/types';

interface ConversationWithUser extends Omit<Conversation, 'profile'> {
  profile?: { username: string };
  messageCount?: number;
}

const LogsPage: React.FC = () => {
  const [conversations, setConversations] = useState<ConversationWithUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 20;

  const [detailOpen, setDetailOpen] = useState(false);
  const [detailMessages, setDetailMessages] = useState<ConversationMessage[]>([]);
  const [detailTitle, setDetailTitle] = useState('');

  const loadConversations = useCallback(async () => {
    setLoading(true);

    let query = supabase
      .from('conversations')
      .select('*, profile:profiles!conversations_user_id_fkey(username)')
      .order('created_at', { ascending: false })
      .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

    if (dateFrom) query = query.gte('created_at', dateFrom);
    if (dateTo) query = query.lte('created_at', dateTo + 'T23:59:59');

    const { data, error } = await query;
    setLoading(false);

    if (!error && data) {
      setConversations(Array.isArray(data) ? data : []);
    }
  }, [page, dateFrom, dateTo]);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  const viewDetail = async (conv: ConversationWithUser) => {
    const { data, error } = await supabase
      .from('conversation_messages')
      .select('*')
      .eq('conversation_id', conv.id)
      .order('created_at', { ascending: true });

    if (!error && data) {
      setDetailMessages(Array.isArray(data) ? data : []);
      setDetailTitle(conv.title);
      setDetailOpen(true);
    } else {
      toast.error('加载对话详情失败');
    }
  };

  const exportLogs = () => {
    const rows = [['对话标题', '用户', '创建时间', '对话ID']];
    conversations.forEach((c) => {
      rows.push([
        c.title,
        c.profile?.username || '未知',
        new Date(c.created_at).toLocaleString('zh-CN'),
        c.id,
      ]);
    });
    const csv = rows.map((r) => r.map((cell) => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `对话日志_${new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('导出成功');
  };

  const filteredConversations = conversations.filter((c) => {
    if (!searchQuery) return true;
    return c.title.includes(searchQuery) || (c.profile?.username || '').includes(searchQuery);
  });

  return (
    <AdminLayout>
      <div className="space-y-4">
        {/* 筛选区 */}
        <div className="flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-40">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="搜索对话标题或用户名..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Label className="text-sm font-normal text-muted-foreground whitespace-nowrap">开始日期</Label>
            <Input
              type="date"
              value={dateFrom}
              onChange={(e) => { setDateFrom(e.target.value); setPage(0); }}
              className="w-36"
            />
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Label className="text-sm font-normal text-muted-foreground whitespace-nowrap">结束日期</Label>
            <Input
              type="date"
              value={dateTo}
              onChange={(e) => { setDateTo(e.target.value); setPage(0); }}
              className="w-36"
            />
          </div>
          <Button variant="outline" onClick={exportLogs} className="h-9 shrink-0">
            <Download className="w-4 h-4 mr-1.5" />
            导出 CSV
          </Button>
        </div>

        {/* 数据表格 */}
        <Card>
          <div className="w-full max-w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap min-w-40">对话标题</TableHead>
                  <TableHead className="whitespace-nowrap">用户</TableHead>
                  <TableHead className="whitespace-nowrap">状态</TableHead>
                  <TableHead className="whitespace-nowrap">创建时间</TableHead>
                  <TableHead className="whitespace-nowrap text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">加载中...</TableCell>
                  </TableRow>
                ) : filteredConversations.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      暂无对话日志
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredConversations.map((conv) => (
                    <TableRow key={conv.id}>
                      <TableCell className="whitespace-nowrap font-medium max-w-52">
                        <span className="truncate block">{conv.title}</span>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                        {conv.profile?.username || '未知用户'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant={conv.is_active ? 'default' : 'secondary'}>
                          {conv.is_active ? '活跃' : '已关闭'}
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                        {new Date(conv.created_at).toLocaleString('zh-CN')}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => viewDetail(conv)}
                          title="查看详情"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>

        {/* 分页 */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            共 {filteredConversations.length} 条记录
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
            >
              上一页
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => p + 1)}
              disabled={conversations.length < PAGE_SIZE}
            >
              下一页
            </Button>
          </div>
        </div>
      </div>

      {/* 对话详情对话框 */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-balance">{detailTitle}</DialogTitle>
            <DialogDescription>对话完整记录</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {detailMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                    msg.role === 'user' ? 'bg-secondary' : 'bg-primary/10'
                  }`}
                >
                  {msg.role === 'user'
                    ? <User className="w-3.5 h-3.5 text-secondary-foreground" />
                    : <Bot className="w-3.5 h-3.5 text-primary" />}
                </div>
                <div
                  className={`max-w-[80%] px-3 py-2 rounded text-sm ${
                    msg.role === 'user'
                      ? 'bg-secondary text-secondary-foreground'
                      : 'bg-muted text-foreground border border-border'
                  }`}
                >
                  <pre className="whitespace-pre-wrap font-sans leading-relaxed">{msg.content}</pre>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(msg.created_at).toLocaleTimeString('zh-CN')}
                  </p>
                </div>
              </div>
            ))}
            {detailMessages.length === 0 && (
              <p className="text-center text-muted-foreground py-4">暂无消息记录</p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default LogsPage;
