import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  BookOpen,
  Send,
  Plus,
  Trash2,
  LogOut,
  MessageSquare,
  Settings,
  Menu,
  Bot,
  User,
} from 'lucide-react';
import type { ChatMessage, Conversation } from '@/types/types';

const ChatPage: React.FC = () => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [requestCount, setRequestCount] = useState(0);
  const [requestResetTime, setRequestResetTime] = useState(Date.now());

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // 滚动到底部
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  // 加载对话列表
  const loadConversations = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .order('updated_at', { ascending: false })
      .limit(50);

    if (!error && data) {
      setConversations(Array.isArray(data) ? data : []);
    }
  }, [user]);

  // 加载对话消息
  const loadMessages = useCallback(async (conversationId: string) => {
    const { data, error } = await supabase
      .from('conversation_messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })
      .limit(100);

    if (!error && data) {
      const msgs: ChatMessage[] = (Array.isArray(data) ? data : []).map((m) => ({
        id: m.id,
        role: m.role as 'user' | 'assistant',
        content: m.content,
        created_at: m.created_at,
      }));
      setMessages(msgs);
    }
  }, []);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadConversations();
  }, [user, navigate, loadConversations]);

  // 切换对话
  const selectConversation = (convId: string) => {
    setCurrentConversationId(convId);
    loadMessages(convId);
    setSidebarOpen(false);
  };

  // 新建对话
  const newConversation = () => {
    setCurrentConversationId(null);
    setMessages([]);
    setSidebarOpen(false);
  };

  // 删除对话
  const deleteConversation = async (convId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const { error } = await supabase
      .from('conversations')
      .update({ is_active: false })
      .eq('id', convId);

    if (!error) {
      setConversations((prev) => prev.filter((c) => c.id !== convId));
      if (currentConversationId === convId) {
        setCurrentConversationId(null);
        setMessages([]);
      }
    }
  };

  // 发送消息
  const sendMessage = async () => {
    const question = inputValue.trim();
    if (!question) return;
    if (isLoading) return;

    // 限流检查
    const now = Date.now();
    if (now - requestResetTime > 60000) {
      setRequestCount(0);
      setRequestResetTime(now);
    }
    if (requestCount >= 20) {
      toast.error('请求过于频繁，请稍后再试');
      return;
    }

    setInputValue('');
    setIsLoading(true);
    setRequestCount((c) => c + 1);

    // 乐观更新：添加用户消息
    const userMsg: ChatMessage = {
      id: `tmp-user-${Date.now()}`,
      role: 'user',
      content: question,
    };
    const loadingMsg: ChatMessage = {
      id: `tmp-loading-${Date.now()}`,
      role: 'assistant',
      content: '',
      isLoading: true,
    };

    setMessages((prev) => [...prev, userMsg, loadingMsg]);

    try {
      // 构建消息历史（最近10轮）
      const historyMessages = messages.slice(-20).map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const { data, error } = await supabase.functions.invoke('campus-chat', {
        body: {
          question,
          conversationId: currentConversationId,
          messages: historyMessages,
        },
      });

      if (error) {
        const errMsg = await error?.context?.text?.();
        throw new Error(errMsg || error.message);
      }

      const { answer, conversationId: newConvId } = data;

      // 更新消息列表
      setMessages((prev) => [
        ...prev.filter((m) => !m.isLoading && m.id !== userMsg.id),
        { ...userMsg, id: `${Date.now()}-user` },
        {
          id: `${Date.now()}-assistant`,
          role: 'assistant',
          content: answer,
        },
      ]);

      // 更新对话ID
      if (newConvId && !currentConversationId) {
        setCurrentConversationId(newConvId);
        await loadConversations();
      } else if (currentConversationId) {
        // 更新对话的 updated_at
        await supabase
          .from('conversations')
          .update({ updated_at: new Date().toISOString() })
          .eq('id', currentConversationId);
        await loadConversations();
      }
    } catch (err: unknown) {
      const error = err as Error;
      setMessages((prev) => prev.filter((m) => !m.isLoading));
      toast.error(error.message || '发送失败，请稍后重试');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };

  // 侧边栏内容
  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      {/* 顶部 Logo */}
      <div className="flex items-center gap-2.5 px-4 py-4 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0">
          <BookOpen className="w-4 h-4 text-primary-foreground" />
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-sm truncate">校园智能助手</p>
          <p className="text-xs text-sidebar-foreground/60 truncate">{profile?.username}</p>
        </div>
      </div>

      {/* 新建对话按钮 */}
      <div className="px-3 py-3">
        <Button
          variant="ghost"
          className="w-full justify-start gap-2 h-9 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground border border-sidebar-border"
          onClick={newConversation}
        >
          <Plus className="w-4 h-4" />
          <span className="text-sm">新建对话</span>
        </Button>
      </div>

      {/* 对话列表 */}
      <div className="flex-1 min-h-0 overflow-y-auto px-3 pb-2">
        {conversations.length === 0 ? (
          <div className="text-center py-8 text-sidebar-foreground/40 text-sm">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p>暂无对话记录</p>
          </div>
        ) : (
          <div className="space-y-0.5">
            {conversations.map((conv) => (
              <div
                key={conv.id}
                onClick={() => selectConversation(conv.id)}
                className={`group flex items-center gap-2 px-2 py-2 rounded cursor-pointer transition-colors text-sm ${
                  currentConversationId === conv.id
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'hover:bg-sidebar-accent/50 text-sidebar-foreground'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5 shrink-0 opacity-60" />
                <span className="flex-1 min-w-0 truncate">{conv.title}</span>
                <button
                  onClick={(e) => deleteConversation(conv.id, e)}
                  className="opacity-0 group-hover:opacity-100 text-sidebar-foreground/40 hover:text-destructive transition-opacity shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 底部操作 */}
      <div className="border-t border-sidebar-border p-3 space-y-1">
        {profile?.role === 'admin' && (
          <Button
            variant="ghost"
            className="w-full justify-start gap-2 h-9 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={() => navigate('/admin/knowledge')}
          >
            <Settings className="w-4 h-4" />
            <span className="text-sm">管理后台</span>
          </Button>
        )}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              className="w-full justify-start gap-2 h-9 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-sm">退出登录</span>
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
            <AlertDialogHeader>
              <AlertDialogTitle>确认退出</AlertDialogTitle>
              <AlertDialogDescription>您确定要退出登录吗？</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>取消</AlertDialogCancel>
              <AlertDialogAction onClick={handleLogout}>退出</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* 桌面侧边栏 */}
      <aside className="hidden lg:flex w-60 shrink-0 flex-col border-r border-border">
        <SidebarContent />
      </aside>

      {/* 主内容区 */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* 顶部导航 */}
        <header className="flex items-center gap-3 px-4 h-14 border-b border-border bg-card shrink-0">
          {/* 移动端汉堡菜单 */}
          <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden h-9 w-9">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 bg-sidebar">
              <SidebarContent />
            </SheetContent>
          </Sheet>

          <div className="flex-1 min-w-0">
            <h1 className="font-semibold text-sm truncate">
              {currentConversationId
                ? conversations.find((c) => c.id === currentConversationId)?.title || '对话中'
                : '新对话'}
            </h1>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9"
            onClick={newConversation}
            title="新建对话"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </header>

        {/* 消息区域 */}
        <ScrollArea className="flex-1">
          <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
            {messages.length === 0 && (
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Bot className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-lg font-medium text-foreground mb-2 text-balance">你好！我是校园智能助手</h2>
                <p className="text-muted-foreground text-sm max-w-sm mx-auto text-pretty">
                  我可以回答关于课程信息、办事流程、规章制度、校园活动等各类校园问题。请随时向我提问！
                </p>
                <div className="mt-6 flex flex-wrap gap-2 justify-center">
                  {['图书馆借阅规定', '成绩单如何开具', '学生请假流程'].map((q) => (
                    <button
                      key={q}
                      onClick={() => setInputValue(q)}
                      className="px-3 py-1.5 rounded-full border border-border text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`message-enter flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                {/* 头像 */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    msg.role === 'user'
                      ? 'bg-secondary text-secondary-foreground'
                      : 'bg-primary/10 text-primary'
                  }`}
                >
                  {msg.role === 'user' ? (
                    <User className="w-4 h-4" />
                  ) : (
                    <Bot className="w-4 h-4" />
                  )}
                </div>

                {/* 消息内容 */}
                <div
                  className={`max-w-[75%] px-4 py-3 rounded-lg text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-secondary text-secondary-foreground'
                      : 'bg-card border border-border shadow-sm text-card-foreground'
                  }`}
                >
                  {msg.isLoading ? (
                    <span className="typing-cursor text-muted-foreground">思考中</span>
                  ) : (
                    <pre className="whitespace-pre-wrap font-sans">{msg.content}</pre>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* 输入区域 */}
        <div className="border-t border-border bg-card p-4 shrink-0">
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-2 items-end">
              <Textarea
                ref={textareaRef}
                placeholder="输入您的问题，按 Enter 发送，Shift+Enter 换行..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isLoading}
                rows={1}
                className="flex-1 min-w-0 resize-none min-h-10 max-h-40 py-2.5 px-3 text-sm"
                style={{ height: 'auto' }}
              />
              <Button
                onClick={sendMessage}
                disabled={isLoading || !inputValue.trim()}
                size="icon"
                className="h-10 w-10 shrink-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-1.5 text-center">
              AI 回复仅供参考，重要事项请以学校官方通知为准
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
