/**
 * 创建管理员账号脚本
 * 运行方式: node scripts/create-admin.mjs
 */

import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config({ path: join(__dirname, '../.env') });

const SUPABASE_URL = process.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !SERVICE_KEY) {
  console.error('缺少环境变量，请检查 .env 文件');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const supabaseAdmin = createClient(SUPABASE_URL, SERVICE_KEY);

// 管理员账号信息
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'Campus@Admin#2026!X';
const ADMIN_EMAIL = `${ADMIN_USERNAME}@miaoda.com`;

async function createAdmin() {
  console.log('📦 开始创建管理员账号...');

  // 步骤1：注册账号（触发 handle_new_user 自动创建 profiles 行）
  const { data: authData, error: signUpError } = await supabase.auth.signUp({
    email: ADMIN_EMAIL,
    password: ADMIN_PASSWORD,
  });

  if (signUpError) {
    if (signUpError.message.includes('already registered')) {
      console.log('⚠️  账号已存在，尝试更新角色...');
    } else {
      console.error('❌ 注册失败:', signUpError.message);
      process.exit(1);
    }
  } else {
    console.log(`✅ 账号注册成功: ${ADMIN_EMAIL}`);
  }

  // 等待 trigger 执行
  await new Promise((resolve) => setTimeout(resolve, 1500));

  // 步骤2：使用 service_role 将角色更新为 admin
  const userId = authData?.user?.id;

  if (userId) {
    const { error: updateError } = await supabaseAdmin
      .from('profiles')
      .update({ role: 'admin' })
      .eq('id', userId);

    if (updateError) {
      console.error('❌ 角色更新失败:', updateError.message);
    } else {
      console.log('✅ 角色已更新为 admin');
    }
  } else {
    // 如果 user 已存在，按用户名查找
    const { data: existingProfile } = await supabaseAdmin
      .from('profiles')
      .select('id')
      .eq('username', ADMIN_USERNAME)
      .maybeSingle();

    if (existingProfile) {
      const { error: updateError } = await supabaseAdmin
        .from('profiles')
        .update({ role: 'admin' })
        .eq('id', existingProfile.id);

      if (updateError) {
        console.error('❌ 角色更新失败:', updateError.message);
      } else {
        console.log('✅ 角色已更新为 admin');
      }
    }
  }

  console.log('\n🎉 管理员账号创建完成！');
  console.log('================================');
  console.log(`  用户名: ${ADMIN_USERNAME}`);
  console.log(`  密码:   ${ADMIN_PASSWORD}`);
  console.log('================================');
  console.log('⚠️  请妥善保存以上凭据，并及时修改密码！');
}

createAdmin().catch(console.error);
