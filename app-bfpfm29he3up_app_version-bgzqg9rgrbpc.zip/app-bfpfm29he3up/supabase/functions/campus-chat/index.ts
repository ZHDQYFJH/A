import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

    // 使用用户授权
    const authHeader = req.headers.get('Authorization')
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader! } },
    })
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey)

    // 验证用户身份
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return new Response(JSON.stringify({ error: '未授权访问' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // 检查用户是否被禁用
    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('is_active')
      .eq('id', user.id)
      .maybeSingle()

    if (!profile?.is_active) {
      return new Response(JSON.stringify({ error: '账号已被禁用，请联系管理员' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const { question, conversationId, messages } = await req.json()

    if (!question?.trim()) {
      return new Response(JSON.stringify({ error: '请输入问题' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // 获取 AI 配置
    const { data: aiConfig } = await supabaseAdmin
      .from('ai_config')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (!aiConfig) {
      return new Response(JSON.stringify({ error: 'AI 引擎未配置，请联系管理员' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // 从知识库检索相关内容（关键词匹配）
    const keywords = question.split(/[\s，,。！？!?]+/).filter((w: string) => w.length > 1)
    let knowledgeContext = ''
    const knowledgeRefs: string[] = []

    if (keywords.length > 0) {
      const { data: knowledgeItems } = await supabaseAdmin
        .from('knowledge_items')
        .select('id, title, content, keywords')
        .eq('status', 'enabled')
        .limit(20)

      if (knowledgeItems && knowledgeItems.length > 0) {
        // 基于关键词匹配打分
        const scored = knowledgeItems.map((item: { id: string; title: string; content: string; keywords: string[] }) => {
          let score = 0
          const itemText = `${item.title} ${item.content} ${(item.keywords || []).join(' ')}`
          for (const kw of keywords) {
            if (itemText.includes(kw)) score++
          }
          return { ...item, score }
        }).filter((item: { score: number }) => item.score > 0)
          .sort((a: { score: number }, b: { score: number }) => b.score - a.score)
          .slice(0, 5)

        if (scored.length > 0) {
          knowledgeContext = '\n\n【参考知识库】\n' + scored.map((item: { id: string; title: string; content: string }) => {
            knowledgeRefs.push(item.id)
            return `**${item.title}**\n${item.content}`
          }).join('\n\n---\n\n')
        }
      }
    }

    // 获取 API 密钥（优先使用配置中的，其次使用环境变量）
    const apiKey = aiConfig.api_key || Deno.env.get('DEEPSEEK_API_KEY') || ''
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'AI API 密钥未配置，请在管理后台配置 API 密钥' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const apiBaseUrl = aiConfig.api_base_url || 'https://api.deepseek.com'
    const modelName = aiConfig.model_name || 'deepseek-chat'
    const systemPrompt = aiConfig.system_prompt + knowledgeContext

    // 构建消息历史（最近10轮）
    const recentMessages = (messages || []).slice(-20).map((m: { role: string; content: string }) => ({
      role: m.role,
      content: m.content,
    }))

    const chatMessages = [
      { role: 'system', content: systemPrompt },
      ...recentMessages,
      { role: 'user', content: question },
    ]

    // 调用 AI API
    let aiApiUrl = `${apiBaseUrl}/v1/chat/completions`

    const aiResponse = await fetch(aiApiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: modelName,
        messages: chatMessages,
        temperature: parseFloat(aiConfig.temperature) || 0.7,
        max_tokens: aiConfig.max_tokens || 2048,
      }),
    })

    if (!aiResponse.ok) {
      const errText = await aiResponse.text()
      console.error('AI API 调用失败:', errText)
      return new Response(JSON.stringify({ error: '系统繁忙，请稍后重试' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const aiData = await aiResponse.json()
    const answer = aiData.choices?.[0]?.message?.content || '抱歉，无法生成回答'

    // 保存对话消息
    let targetConversationId = conversationId

    if (!targetConversationId) {
      // 创建新对话
      const title = question.length > 20 ? question.substring(0, 20) + '...' : question
      const { data: newConv, error: convError } = await supabase
        .from('conversations')
        .insert({ user_id: user.id, title })
        .select('id')
        .maybeSingle()

      if (convError) {
        console.error('创建对话失败:', convError)
      } else {
        targetConversationId = newConv?.id
      }
    }

    if (targetConversationId) {
      await supabase
        .from('conversation_messages')
        .insert([
          { conversation_id: targetConversationId, role: 'user', content: question },
          { conversation_id: targetConversationId, role: 'assistant', content: answer, knowledge_refs: knowledgeRefs },
        ])
    }

    return new Response(
      JSON.stringify({
        answer,
        conversationId: targetConversationId,
        knowledgeRefs,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (error) {
    console.error('处理请求失败:', error)
    return new Response(JSON.stringify({ error: '服务器内部错误，请稍后重试' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
