
-- 用户角色枚举
CREATE TYPE public.user_role AS ENUM ('user', 'admin');

-- 知识条目状态枚举
CREATE TYPE public.knowledge_status AS ENUM ('enabled', 'disabled', 'pending', 'rejected');

-- 用户资料表
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  email text,
  role public.user_role NOT NULL DEFAULT 'user',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 触发器：新用户注册时自动同步到 profiles
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, username, email, role)
  VALUES (
    NEW.id,
    split_part(NEW.email, '@', 1),
    NEW.email,
    'user'::public.user_role
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- 知识库分类表
CREATE TABLE public.knowledge_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  parent_id uuid REFERENCES public.knowledge_categories(id) ON DELETE SET NULL,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 知识条目表
CREATE TABLE public.knowledge_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  keywords text[] DEFAULT '{}',
  category_id uuid REFERENCES public.knowledge_categories(id) ON DELETE SET NULL,
  status public.knowledge_status NOT NULL DEFAULT 'pending',
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reviewed_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  review_comment text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- AI 引擎配置表
CREATE TABLE public.ai_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL DEFAULT 'deepseek',
  api_key text,
  api_base_url text,
  model_name text NOT NULL DEFAULT 'deepseek-chat',
  system_prompt text NOT NULL DEFAULT '你是一个校园智能助手，专门回答关于校园信息的问题。请根据提供的知识库内容，准确、友好地回答用户的问题。如果知识库中没有相关信息，请基于通用知识给出合理回答，并建议用户联系相关部门获取最新信息。',
  temperature numeric(3,2) NOT NULL DEFAULT 0.7,
  max_tokens int NOT NULL DEFAULT 2048,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 对话会话表
CREATE TABLE public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT '新对话',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 对话消息表
CREATE TABLE public.conversation_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  knowledge_refs uuid[] DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_knowledge_items_category ON public.knowledge_items(category_id);
CREATE INDEX idx_knowledge_items_status ON public.knowledge_items(status);
CREATE INDEX idx_conversations_user ON public.conversations(user_id);
CREATE INDEX idx_messages_conversation ON public.conversation_messages(conversation_id);
CREATE INDEX idx_messages_created_at ON public.conversation_messages(created_at);

-- 插入默认 AI 配置
INSERT INTO public.ai_config (platform, api_base_url, model_name, system_prompt)
VALUES (
  'deepseek',
  'https://api.deepseek.com',
  'deepseek-chat',
  '你是一个专业的校园智能助手，服务于高校师生群体。你的职责是：
1. 准确回答关于课表、教室、校园活动、办事流程、规章制度等校园信息
2. 根据提供的知识库内容给出精准答复
3. 若知识库无相关信息，基于通用知识给出合理回答，并建议用户联系相关部门
4. 保持友好、专业的对话风格
5. 对于不确定的信息，明确告知用户'
);

-- 插入示例知识库分类
INSERT INTO public.knowledge_categories (name, description, sort_order) VALUES
  ('办事流程', '校园各类事务的办理流程指南', 1),
  ('规章制度', '学校规章制度与管理规定', 2),
  ('校园活动', '校园文化活动与社团信息', 3),
  ('教学信息', '课程、教室、考试等教学相关信息', 4),
  ('生活服务', '食堂、宿舍、图书馆等生活服务信息', 5);

-- 插入示例知识条目
INSERT INTO public.knowledge_items (title, content, keywords, category_id, status)
SELECT 
  '成绩单开具流程',
  '学生开具成绩单需要以下步骤：\n1. 登录教务管理系统，在"成绩管理"模块申请成绩单\n2. 填写申请原因和份数（每次最多申请5份）\n3. 提交申请后等待1-3个工作日审核\n4. 审核通过后，前往教务处（行政楼203室）凭学生证领取\n5. 如需加盖学校公章，需额外申请公章盖章，处理时间为2个工作日\n\n工作时间：周一至周五 8:30-11:30，14:00-17:30',
  ARRAY['成绩单', '成绩证明', '开具', '教务处'],
  id,
  'enabled'
FROM public.knowledge_categories WHERE name = '办事流程'
LIMIT 1;

INSERT INTO public.knowledge_items (title, content, keywords, category_id, status)
SELECT 
  '图书馆借阅规定',
  '图书馆借阅规定如下：\n1. 借阅资格：持有效学生证/工作证的在校师生\n2. 借阅数量：本科生最多借阅10册，研究生15册，教职工20册\n3. 借阅期限：普通图书为30天，可续借2次，每次续借30天\n4. 逾期处理：逾期不还每册每天罚款0.1元\n5. 开放时间：周一至周日 8:00-22:00（节假日适当调整）\n6. 自习区：全天开放，需凭校园卡刷卡进入',
  ARRAY['图书馆', '借阅', '还书', '续借'],
  id,
  'enabled'
FROM public.knowledge_categories WHERE name = '生活服务'
LIMIT 1;

INSERT INTO public.knowledge_items (title, content, keywords, category_id, status)
SELECT 
  '学生请假流程',
  '学生请假办理流程：\n1. 事假/病假（1-3天）：在教务系统提交请假申请，经辅导员审批即可\n2. 事假（3天以上）：需辅导员审批后，提交院系教学秘书备案\n3. 病假（需就医证明）：附医院诊断证明，提交辅导员审批\n4. 紧急情况：可先电话通知辅导员，事后补办请假手续\n5. 旷课处理：旷课3次及以上取消期末考试资格\n\n注意：因特殊情况无法返校者，需提前联系辅导员说明情况',
  ARRAY['请假', '病假', '事假', '辅导员'],
  id,
  'enabled'
FROM public.knowledge_categories WHERE name = '办事流程'
LIMIT 1;
