
-- 启用 RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.knowledge_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.knowledge_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_messages ENABLE ROW LEVEL SECURITY;

-- 辅助函数
CREATE OR REPLACE FUNCTION has_role(uid uuid, role_name text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = role_name::user_role
  );
$$;

CREATE OR REPLACE FUNCTION is_active_user(uid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.is_active = true
  );
$$;

-- profiles 策略
CREATE POLICY "管理员完全访问" ON profiles
  FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "用户查看自己的资料" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "用户更新自己的资料（不能改角色）" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- 公开视图
CREATE VIEW public_profiles AS
  SELECT id, username, role, is_active FROM profiles;

-- knowledge_categories 策略
CREATE POLICY "所有已登录用户可查看分类" ON knowledge_categories
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "管理员管理分类" ON knowledge_categories
  FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'));

-- knowledge_items 策略
CREATE POLICY "用户可查看已启用的知识条目" ON knowledge_items
  FOR SELECT TO authenticated USING (status = 'enabled' OR has_role(auth.uid(), 'admin'));

CREATE POLICY "管理员完全管理知识条目" ON knowledge_items
  FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'));

-- ai_config 策略
CREATE POLICY "管理员管理AI配置" ON ai_config
  FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "用户可查看AI配置（不含密钥）" ON ai_config
  FOR SELECT TO authenticated USING (true);

-- conversations 策略
CREATE POLICY "用户管理自己的对话" ON conversations
  FOR ALL TO authenticated USING (auth.uid() = user_id AND is_active_user(auth.uid()));

CREATE POLICY "管理员查看所有对话" ON conversations
  FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'));

-- conversation_messages 策略
CREATE POLICY "用户查看自己对话的消息" ON conversation_messages
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "用户插入自己对话的消息" ON conversation_messages
  FOR INSERT TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "管理员查看所有消息" ON conversation_messages
  FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'));

-- 启用实时推送
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversation_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;
